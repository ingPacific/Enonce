

let nonb = prompt("Tape yon nonb ki komanse nan 1 rive nan 10 : ");
for (let i = 1; i <= 10; i++) {
    let rezilta;
    console.log(i * nonb);
}


